# Reverse-engineering a RuoYi-based SaaS admin (menu + API + fields) with a token

Technique for "clone this competitor site's structure" requests: given a URL + JWT, extract the full menu tree, API route list, and field/table schema WITHOUT a browser (curl + minified-JS analysis). Proven against yibaoshidai.com (frontend) / glownest.cn (backend, RuoYi-style).

## 1. Fetch the SPA shell, find the real backend
The index page is a tiny Vue SPA shell (~4KB). The backend is elsewhere:
```bash
curl -s https://site.com/index | grep -oE '<script[^>]+src="[^"]+"'   # find main bundle, e.g. /assets/index-XXXX.js
curl -s https://site.com/assets/index-XXXX.js -o main.js
grep -oE 'baseURL:\s*["'"'][^"'"']+["'"']' main.js
# → baseURL: https://www.glownest.cn/insurance   ← REAL backend (different domain than the frontend!)
```
The frontend domain only serves static assets; all API calls go to `baseURL` (often a different host).

## 2. Discover API paths from the minified bundle
Minified bundles still contain literal URL fragments. Use several regexes:
```python
import re
candidates = re.findall(r"['\"]([/a-zA-Z][a-zA-Z0-9_\-/{}:]{3,50})['\"]", js)
# filter: must contain '/', exclude .css/.js/.png/.svg/.ico/node_modules/webpack
# group by top segment: /goods/..., /order/..., /scheme/..., /common/...
```
RuoYi-standard endpoints found: `/getRouters`, `/getInfo`, `/common/commonDict`, `/system/dict/data/list`, `/common/infoInit`, `/common/getCommonGoodsConfigs`, `/renewalOperation/detail`, `/product/qrcode/list`, `/notice/config/findByPage`, etc. Non-RuoYi forks use `{code,message,data,success}` envelope instead of `{code,msg,data}` — adapt parsing accordingly.

## 3. Auth header format — probe several
Different forks accept different headers. Try in order:
```bash
for H in "Admin-Token: $TOKEN" "admin-token: $TOKEN" "Authorization: Bearer $TOKEN" "token: $TOKEN"; do
  curl -s -H "$H" https://backend/getRouters | head -c 120; echo "  <= $H"
done
```
Observed: `Authorization: Bearer` worked; `Admin-Token` returned 401. Once one works, use it everywhere.

## 4. Extract the full menu tree (no UI needed)
`GET /getRouters` returns the router tree: `path`, `name`, `component`, `hidden`, `meta.title/icon`, children. This is the site's complete navigation — dump it hierarchically:
```python
def dump(r, i=0):
    print("  "*i + f"[{r.get('path')}] {r.get('meta',{}).get('title')} (icon={r.get('meta',{}).get('icon')}, hidden={r.get('hidden')})")
    for c in r.get('children',[]): dump(c, i+1)
```

## 5. Get permissions + user context
`GET /getInfo` returns `permissions: [...]` — the exact perm strings (`order:issue`, `channel:account`, `settlement:detail`...) that reveal what modules exist and what the token can do. Also `GET /common/infoInit` gives channel/domain branding.

## 6. Infer field schemas from empty-request errors
List endpoints often 404 or 500 on a low-privilege token. But **validation errors leak required field names**:
```bash
curl -s -X POST -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{}' \
  https://backend/renewalOperation/operationList
# → {"message":"operationList.goodsCode 不能为空"}  → field `goodsCode` required
curl -s -X POST ... -d '{}' https://backend/notice/config/save
# → "通知标题不能为空" → field title required
```
Batch-probe: for each discovered endpoint, POST `{}` (and GET with a guessed id like `?goodsCode=COM521371`) and collect all error messages. Each `xxx不能为空`/`xxx不能为空` names a real column. Combine with `renewalOperation/detail?goodsCode=X` which returns the full object schema (goodsName, goodsType, correctOperationList[]...).

## 7. Dict endpoints (may be permission-gated)
`/system/dict/data/type/{type}` and `/system/dict/data/list?dictType=X` expose dictionary values. On restricted tokens they return 权限不足 — accept and move on; the user will provide a higher-privilege token later or you fill from domain knowledge.

## 8. Deliverable for "1:1 clone the site"
When the token lacks data access, pivot the plan: extract what you can (menu tree 100%, API paths ~50, some schemas) and for the rest **hand-design tables from the menu tree + insurance-domain knowledge** (user's preference: "数据表字段可以看一下产品字段，1:1"). Produce: `01_sys_menu.sql` (M/C/F menus per extracted tree), `02_jl_tables.sql` (CREATE TABLE per C menu), `03_dict_data.sql` (dict types + data), then run through the generator (see batch-generator-landing.md).

## Pitfalls
- The SPA bundle may be ONE giant minified file (no dynamic import chunks, no readable route strings) — field labels are NOT in the JS (schema-driven backend), so JS regexing finds upload hints only. Don't waste time grepping for business labels.
- Backend host from `baseURL` may differ from the domain the user gave — always check.
- Token expiry: JWT works for hours; if 401s start mid-session, ask the user for a fresh token.
- 402/429 in other contexts (LLM API quota) are unrelated to the target site — don't conflate.
