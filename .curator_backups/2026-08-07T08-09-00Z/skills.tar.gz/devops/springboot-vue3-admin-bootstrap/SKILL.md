---
name: springboot-vue3-admin-bootstrap
description: Bootstrap RuoYi Spring Boot 3 + Vue3 admin from source
---

# Spring Boot + Vue3 Admin Bootstrap

Class: deploying + bootstrapping a multi-module Spring Boot 3 + Vue3 admin system (RuoYi-Vue3, RuoYi-Vue-Plus, eladmin, vue-vben-admin or similar) from source/backup to a working dev environment with MySQL + Redis in docker, CRUD APIs generated, and Vite frontend live.

## When to use

Trigger any of:
- "scaffold / build / bootstrap an admin system from source"
- "wire application.yml to docker MySQL/Redis"
- "generate CRUD for ~10-20 business tables" (often `jl_*`, `biz_*`, `sys_*` prefix)
- "RuoYi 部署 / 启动 / 跑起来"
- "multi-module Maven dependency version error"
- "Spring Boot Lookup method resolution failed / class not found at startup"
- "MyBatis mapper XML Table 'xxx' doesn't exist" (placeholder escape bug)
- "Vite dev server won't start, vite: not found"
- "docker-entrypoint-initdb.d not running my new SQL"
- "admin-web 5173 / 80 / 404 / 跨域"
- "menu names / dict labels showing as mojibake (ç³»ç»Ÿç®¡ç†) after fresh MySQL container"
- "RuoYi frontend renders garbled glyphs in Element Plus / icons"
- "RuoYi 4.x Table 'db.sys_notice_read' doesn't exist"
- "18 张表代码生成了但页面 404" / "generated code landed but menu pages 404" / "菜单点了 404"
- "1:1 仿站 / 扒某个保险后台的菜单和字段" (reverse-engineer a RuoYi-style SaaS via token + JS bundle)
- "batchGenCode / 批量生成代码 / generator zip 怎么用"

Don't use for: production hardening (k8s, HTTPS, secrets, HA) — that's `production-readiness` territory. This skill gets the **dev environment** running and the **CRUD layer** complete.

## First rule: USE THE BUILT-IN CODE GENERATOR before hand-writing CRUD

RuoYi / RuoYi-Vue-Plus / eladmin / vue-vben-admin ALL ship a working code generator accessible from the admin UI menu **系统工具 → 代码生成** (path `/tool/gen`). Endpoint: `POST /tool/gen/importTable` (imports a real MySQL table into the generator), then `GET /tool/gen/download/{tableName}` returns a zip containing:

- `{Class}Controller.java` + `Service/Impl` + `Mapper` + `Domain` + XML
- `vue/api/<module>/<business>.js` (axios wrappers for list/get/add/update/del/export)
- `vue/views/<module>/<business>/index.vue` (RuoYi Element Plus CRUD page with query form + table + add/edit dialog + 5 buttons)
- `<business>Menu.sql` — INSERT statements for `sys_menu` + 5 button permissions (query/add/edit/remove/export). Idempotent: re-importing appends NEW menu rows via `@parentId := LAST_INSERT_ID()`

**Recipe for using the generator** (instead of hand-writing):

1. Confirm table exists in MySQL (or `CREATE TABLE` it first).
2. Login as admin → System Tools → Code Gen → **Import** the table (form: `tplWebType=element-plus`, `tplCategory=crud`).
3. On the edit page: set `packageName=com.<your>.<module>`, edit column display types (`query`/`list`/`edit` flags, dict types).
4. Click **Preview** to see what files will be generated. Click **Generate Code** → downloads `jonlink.zip`.
5. Unzip → copy `main/java/**` into your module's `src/main/java/`, copy `vue/**` into `admin-web/src/`.
6. Run the `<business>Menu.sql` against the DB to register the menu.
7. Rebuild backend + frontend, restart services.

**Default generator quirks** that bite you:

- Package name is hardcoded in `generator.yml` (`com.jonlink.system`). UI import form lets you override per-table — always set this before generate.
- Generator paths land in `/system/<business>` by default — for business modules, edit `vm/java/controller.java.vm` and `vm/sql/sql.vm` to point to `/<your>/<business>` and parent_id of your module's top-level menu.
- Generator `tplCategory=crud` outputs ONE list page; for tree/sub/master-detail use `tree` or `sub`. No support for non-Element UI targets (e.g. vant) — see references for H5 workaround.

**When NOT to use the generator** (hand-write instead):

- Need non-standard interaction (drag-drop forms, canvas editors, multi-tab wizards, dynamic schema-driven forms).
- Need strict field validation beyond what `@NotBlank`/`@Size` annotations give.
- Need nested master-detail forms (use `tplCategory=sub` for simple 1:N, hand-write for complex).
- Need H5/mobile (vant) — generator only outputs Element Plus admin UI.

The user's preference is **generator-first**. Hand-writing CRUD then asking the generator to "fix it" or "regenerate the same table" is a wasteful loop. Generate once, copy to module, tweak details by hand.

## Quick start (the 6-step sequence)

1. **Restore source** (tar -xzf → place under project root)
2. **Verify rename complete** if migrated (`grep -r 'old.pkg' src/` → must be 0)
3. **Bring up DB**: `docker compose up -d mysql redis` with `volumes: ./sql:/docker-entrypoint-initdb.d:ro`. **CRITICAL**: prepend a `00-set-charset.sql` wrapper (see pitfall 13) — MySQL container defaults to latin1 connection for init SQL, which corrupts every Chinese row.
4. **Patch application.yml**: MySQL URL → `jdbc:mysql://127.0.0.1:3306/<db>?allowPublicKeyRetrieval=true`; Redis host → `127.0.0.1`, password
5. **`mvn install -DskipTests` then `java -jar target/<app>.jar`** — do NOT use `spring-boot:run` for multi-module (see pitfalls)
6. **Frontend**: `npm install --include=dev` (NOT plain `npm install` — see pitfalls), then `npm run dev`. **Also delete the `css: { postcss: { plugins: [...] } }` charset-removal block** in `admin-web/vite.config.js` (see pitfall 14).

If any step fails, jump to the matching `references/<topic>.md` file.

## Pitfalls (READ THESE BEFORE CODING)

### 1. `mvn spring-boot:run` fails with "Lookup method resolution failed" in multi-module

`org.springframework.boot.devtools.restart.classholder.RestartClassLoader` cannot resolve classes from sibling modules that were added to the reactor after devtools started. Symptoms: `BeanCreationException: Error creating bean with name 'JlXxxController': Lookup method resolution failed` immediately after adding a new module's controller.

**Fix**: skip devtools run entirely for multi-module. Use:
```bash
mvn install -DskipTests
java -jar target/<module>-admin.jar
```

### 2. `application.yml` uses CRLF; the `patch` tool breaks it

Spring Boot config files in this codebase are CRLF (`\r\n`). The `patch` tool re-validates as LF-YAML and refuses to write. Symptoms: `mapping values are not allowed here` from yamllint.

**Fix**: use Python `execute_code` with binary read/write to preserve line endings:
```python
path = '/path/to/application.yml'
with open(path, 'rb') as f: data = f.read()
data = data.replace(b'host: localhost\r\n', b'host: 127.0.0.1\r\n')
with open(path, 'wb') as f: f.write(data)
```
Or use `sed -i` with CRLF-aware tools.

### 3. New module added to parent `<modules>` → child poms need `<dependencyManagement>`

When you add `jonlink-insure` to `<modules>`, any module that depends on it (e.g. `jonlink-admin`) gets `'dependencies.dependency.version' is missing` UNLESS the parent has:
```xml
<dependencyManagement>
  ...
  <dependency>
    <groupId>com.example</groupId>
    <artifactId>jonlink-insure</artifactId>
    <version>${project.version}</version>
  </dependency>
</dependencyManagement>
```

### 4. `docker-entrypoint-initdb.d/*.sql` only runs on FIRST container start

If the MySQL container was created before you added SQL files, **new files are silently ignored**. Two fixes:
- **Fresh start** (loses data): `docker compose down && rm -rf deploy/data/mysql && docker compose up -d`
- **Hot-apply** (keeps data): loop over files and `docker exec jonlink-mysql mysql -uroot -p<pwd> <db> < /path/to/file.sql`

### 5. MyBatis mapper XML generated with `#{name}` but real table is `jl_apply_record` (camelCase leak)

When generating XML via Python template substitution, if the table name placeholder consumed adjacent text (e.g. `__TABLE__` ate a suffix leaving `jl_<empty>`), the SQL ends up `insert into jl_applyRecord` instead of `insert into jl_apply_record`. The DB then returns `Table 'db.jl_applyRecord' doesn't exist`.

**Fix pattern**: use regex replace with explicit word boundaries:
```python
import re
for f in glob.glob('**/JlXxxMapper.xml'):
    new = re.sub(r'\bjl_([A-Z][a-z]+[A-Z]\w*)\b',
                 lambda m: 'jl_' + snake(m.group(1)), open(f).read())
    open(f, 'w').write(new)
```

### 6. `{{` and `}}` from Python template `.replace()` aren't auto-escaped

Java class bodies contain `{` and `}`. When generating Java code via Python, naive `.replace('__CLS__', cls)` doesn't double-brace. After writing, the Java source has `{{` `}}` which breaks javac with "illegal start of expression" / "class, interface, enum, or record expected".

**Fix**: post-process step to replace all `{{` → `{` and `}}` → `}` after generation, across all generated `.java` files:
```python
for f in glob.glob('**/*.java'):
    with open(f, 'rb') as fh: data = fh.read()
    data = data.replace(b'{{', b'{').replace(b'}}', b'}')
    with open(f, 'wb') as fh: fh.write(data)
```

### 7. Public controller returns 401 — need `@Anonymous`

RuoYi security blocks all unauthenticated requests by default. For public endpoints (H5, captcha, login, swagger), annotate the controller class:
```java
import com.jonlink.common.annotation.Anonymous;
@Anonymous
@RestController
@RequestMapping("/api/h5")
public class H5Controller { ... }
```
The framework's `PermitAllUrlProperties` scans both class-level and method-level `@Anonymous`.

### 8. RuoYi captcha toggle goes through Redis cache

`sys.account.captchaEnabled=false` in `sys_config` only takes effect after `redisCache.getCacheObject(...)` returns the new value. After `UPDATE sys_config`, also `docker exec jonlink-redis redis-cli -a <pwd> FLUSHDB`.

### 9. `npm install` skips devDependencies — frontend dev won't start

Symptoms: `vite: not found` despite `vite` being in `package.json` devDependencies. Some npm 8+ configs default to omitting devDeps in production-like contexts.

**Fix**: `npm install --include=dev` or explicit `npm install --include=dev vite@<version> sass-embedded@<version> unplugin-auto-import ...`

**Also bites yarn**: `NODE_ENV=production` set globally (e.g. by deploy tooling) makes BOTH npm and yarn silently skip devDependencies. Symptom is identical. Confirm with `echo $NODE_ENV` first; if it's `production`, prefix install with `NODE_ENV=development`:

```bash
NODE_ENV=development yarn install --check-files
```

After install, verify the binary exists: `ls node_modules/.bin/vite` — must be present, not just the package directory.

### 10. Vite default port is 80, not 5173 (RuoYi admin-web)

`admin-web/vite.config.js` sets `server.port = 80` to avoid CORS with the backend (which serves admin-web). Needs root or `sudo setcap cap_net_bind_service=+ep $(which node)`. The auto-open `xdg-open ENOENT` error in dev logs is harmless in headless.

### 11. Default RuoYi MySQL URL is `localhost:3306` — needs `allowPublicKeyRetrieval=true` for MySQL 8

MySQL 8 defaults to `caching_sha2_password`. Without `allowPublicKeyRetrieval=true` in JDBC URL, you'll get `Public Key Retrieval is not allowed`. Use:
```
jdbc:mysql://127.0.0.1:3306/<db>?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&allowPublicKeyRetrieval=true
```

### 12. Docker Hub unreachable in China — configure registry mirrors

Default `registry-1.docker.io` times out. Add to `/etc/docker/daemon.json`:
```json
{
  "registry-mirrors": [
    "https://docker.xuanyuan.me",
    "https://docker.1ms.run",
    "https://docker.m.daocloud.io"
  ]
}
```
Then `docker pull docker.1ms.run/library/mysql:8.0` and `docker tag docker.1ms.run/library/mysql:8.0 mysql:8.0`.

### 13. Chinese 乱码 — MySQL container's `docker-entrypoint-initdb.d/*.sql` runs with latin1 connection

**Symptom**: data is in DB, UTF-8 source SQL has Chinese like `'系统管理'`, but the live API returns `ç³»ç»Ÿç®¡ç†` for menu names. `HEX(menu_name)` is `C3A7C2B3...` (double-encoded). Affects every `name`/`title` field in `sys_menu`, `sys_role`, `sys_dict_type`, `sys_dict_data`, `sys_dept`, `sys_post`, `sys_config` — i.e. 100+ rows of 乱码 after a fresh container.

**Root cause**: MySQL Docker image defaults the `docker-entrypoint-initdb.d/*.sql` client connection to `latin1` (not utf8mb4). When the SQL file contains UTF-8 bytes for Chinese characters, MySQL stores them as latin1 → utf8mb4 hybrid = double-encoded mojibake. Same root cause as 双重 UTF-8 编码.

**Fix** (two parts, do BOTH):

**(a) Prevent future builds** — prepend a `00-set-charset.sql` wrapper file that runs FIRST in `docker-entrypoint-initdb.d/`:
```sql
SET NAMES utf8mb4;
SET CHARACTER_SET_CLIENT = utf8mb4;
SET CHARACTER_SET_RESULTS = utf8mb4;
SET CHARACTER_SET_CONNECTION = utf8mb4;
SET collation_connection = utf8mb4_unicode_ci;
```
Filename must sort before other SQL (alphabetical order: `00-` < `01-` < `jl_*`).

**(b) Recover existing data** — run a Python repair script with PyMySQL. Detect double-encoded rows via `byte_len / char_len >= 4` AND `first_byte in (0xC2, 0xC3, 0xC4, 0xC5)`. For each, decode bytes: `bytes.decode('utf-8')` → string with latin1 + extended chars → `bytes(ord(c) for c in s)` → original bytes → `.decode('utf-8')` = correct text. UPDATE with corrected UTF-8 bytes. **Note**: bytes < 25 chars often contain a mix of 2-tier and 3-tier encoding due to 0x9F/0x90/0x86 falling outside latin1 — the recovery loop may need 3+ iterations. For business-critical text (menu names, role names), the more reliable shortcut is: hardcode the correct Chinese name → `UPDATE sys_menu SET menu_name = '系统管理' WHERE menu_id = 1` over 100 rows via dict. See `references/mysql-utf8-recovery.md`.

**Detect on existing install**:
```bash
mysql -h127.0.0.1 -uroot -p<pwd> <db> --default-character-set=latin1 \
  -e "SELECT menu_id, menu_name FROM sys_menu WHERE menu_id IN (1,2,100)"
# expect: 系统管理 / 系统监控 / 用户管理
# if you see mojibake like ç³»ç»Ÿç®¡ç†, the DB has double-encoded rows
```

### 14. RuoYi-Vue3 ships a `charset-removal` postcss plugin → CSS 乱码

**Symptom**: Vite dev server starts fine, login page HTML loads, but **Element Plus / icon fonts render as garbled characters** (boxes, `?`, broken glyphs). Console shows no errors. `curl http://127.0.0.1/` returns correct HTML but the rendered UI is unreadable.

**Root cause**: `admin-web/vite.config.js` contains a postcss plugin block that strips every `@charset "UTF-8";` declaration from imported CSS. Element Plus's CSS (and many vendor stylesheets) declare their own `@charset`; once removed, the CSS parser doesn't know the file is UTF-8 and falls back to wrong encoding for non-ASCII glyphs.

**Fix**: delete the entire `css: { postcss: { plugins: [...] } }` block in `admin-web/vite.config.js`. The `postcssPlugin: 'internal:charset-removal'` was originally added to avoid duplicate `@charset` declarations in bundled CSS — but Element Plus and many icon libraries rely on it being present. Safe to remove. After deletion, restart Vite (it auto-restarts on config change).

### 15. RuoYi 4.x added tables (`sys_notice_read`) not in 3.x init SQL

**Symptom**: backend logs `Table 'jonlink.sys_notice_read' doesn't exist` on first page load. The mapper XML `com.jonlink.system.mapper.SysNoticeReadMapper.xml` is bundled in `jonlink-system-3.9.2.jar` (RuoYi 4.x) but `jonlink_init.sql` is from RuoYi 3.x.

**Fix**: add the missing table to your init SQL and re-run:
```sql
DROP TABLE IF EXISTS sys_notice_read;
CREATE TABLE sys_notice_read (
    read_id   BIGINT NOT NULL AUTO_INCREMENT,
    notice_id INT    NOT NULL,
    user_id   BIGINT NOT NULL,
    read_time DATETIME,
    PRIMARY KEY (read_id),
    UNIQUE KEY uk_notice_user (notice_id, user_id),
    KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='公告已读记录';
```
Or `docker exec jonlink-mysql mysql -uroot -p<pwd> <db> < add_table.sql` to hot-apply.

### 16. MySQL 8 `caching_sha2_password` requires BOTH `allowPublicKeyRetrieval=true` AND a non-localhost user grant

Even with the JDBC URL fix from pitfall 11, backend still fails with `Access denied for user 'jonlink'@'172.18.0.1'` when the JDBC URL uses `localhost`. Why: Docker's internal DNS resolves `localhost` to a host-mode mapping, but Spring connects via the container network IP (e.g. `172.18.0.x`), which doesn't match the user grant on `@'localhost'`. Symptom chain: First error is `Public Key Retrieval is not allowed` (fix: pitfall 11 URL). After that fix, second error appears: `Access denied for user 'jonlink'@'<docker-network-ip>'`.

**Fix**: create a wildcard-host user, not just a localhost one:
```sql
CREATE USER IF NOT EXISTS 'jonlink'@'%' IDENTIFIED WITH mysql_native_password BY '<pwd>';
GRANT ALL ON <db>.* TO 'jonlink'@'%';
FLUSH PRIVILEGES;
```

The `@'%'` matches any source IP. Both `@'localhost'` AND `@'%'` can coexist. The `mysql_native_password` plugin (vs default `caching_sha2_password`) avoids the public-key-retrieval rabbit hole entirely if you can set it at user-create time.

### 17. Can't rebuild but need to change connection params — patch the jar in-place

When you only have the prebuilt `jonlink-admin.jar` (no source/maven on this box) and the URL or password in `BOOT-INF/classes/application-druid.yml` is wrong, do NOT throw the jar away and rebuild from source. Patch it in-place:

```python
import zipfile, shutil, os
src = '/path/to/jonlink-admin.jar'
dst = '/tmp/jonlink-admin-patched.jar'
target = 'BOOT-INF/classes/application-druid.yml'
with zipfile.ZipFile(src, 'r') as zin, zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        data = zin.read(item.filename)
        if item.filename == target:
            data = data.replace(b'old-url-string', b'new-url-string', 1)
        zout.writestr(item, data)
shutil.copy(dst, src)
```

Notes:
- Always keep a backup: `cp jar jar.bak` before patching.
- `writestr(item, data)` on an `item` you didn't read preserves metadata (timestamps, attrs). Don't reconstruct `ZipInfo` manually.
- For YAML edits, edit in binary mode (`'rb'`/`'wb'`) to preserve line endings (see pitfall 2).
- Test: extract the patched file and `grep` to confirm the replacement took.
- For Spring to pick up the change, restart the JVM. `java -jar` exits and re-loads everything from disk.

### 18. Destructive ops: backup-aware restore protocol

When the user says "delete everything in /opt/X and redeploy from /opt/X-backup", do NOT just `rm -rf`. Always follow this 6-step protocol BEFORE touching anything:

1. **Inventory the target dir**: `ls -la /opt/<project>/`, identify subdirs.
2. **Inventory the backup**: `ls -la /opt/<project>-backup/`, `tar -tzf ... | head` to confirm contents parse.
3. **Diff current vs backup**: `diff -rq /opt/<project> /tmp/backup-extract 2>&1 | head` — surface what's about to be lost. Items only-in-target (current) are unrecoverable after deletion.
4. **Enumerate what the backup does NOT cover**: env-installed software (`/opt/jdk`), unrelated projects (`/opt/openlist`), container data volumes (bind mounts that the backup tar excludes), running processes the user might not realize are tied to this dir.
5. **Present a 3-option plan**: (A) full restore from backup, (B) keep code, reset DB only, (C) full nuke including backup. Do NOT pick for them.
6. **After confirmation**: do it as one logical transaction: stop processes → stop containers → `rm -rf` → restore → rebuild → start. If any step fails, halt and report — don't paper over.

Common user assumption: "if I have a backup, redeploy is safe." Reality: backups are point-in-time snapshots; any work since the snapshot is lost. Surface this clearly so the user can choose knowingly.

### 19. Don't blanket-pkill matching process names

`pkill -f "node.*vite"` or `pkill -f "java"` matches the COMMAND STRING, not the actual process identity. If you have two unrelated processes whose argv happens to contain those tokens (e.g. a Vite dev server for admin-web AND h5-insure both contain "node" + "vite"), `pkill -f` will kill both.

**Fix**: identify the exact PIDs first via `ps aux | grep`, then `kill -9 <pid1> <pid2>`. For Java, prefer `pkill -9 -f jonlink-admin.jar` (matches the specific jar filename, won't hit other JVMs).

For backgrounded `npm run dev | tee` processes, the chain is `bash → npm → node → vite`. Killing the npm PID leaves the node child orphaned. Use `pkill -9 -f "node.*vite"` after first identifying which vite dev server you mean.

### 20. Generator velocity bug: Chinese table comments with `（...）` corrupt the Domain file

RuoYi generator renders `readConverterExp` from column comments. If a comment contains parentheses, commas, or quotes — e.g. `配置项 JSON（例如 {"downloadNewPolicy":true}）` or `产品编码（COM000）` — the generated `@Excel(name = "...", readConverterExp = "...")` line becomes a **compile error** (`')' expected`). Comments ending with `（AES加密）`-style suffixes also produce garbage like `readConverterExp = "A=ES加密"`. Unrendered Velocity placeholders also leak through: `/** $column.columnComment */` + `@Excel(name = "${comment}", readConverterExp = "$column.readConverterExp()")`.

**Symptom**: `mvn package` fails with `COMPILATION ERROR ... ')' expected` in `domain/JlXxx.java` line ~30.

**Fix** (batch-clean all generated Domains after landing, before compiling):
```python
import re, glob
for f in glob.glob('**/domain/Jl*.java'):
    c = open(f).read()
    c = re.sub(r'@Excel\(name = "([^"]*)", readConverterExp = "[^"]*"\)', r'@Excel(name = "\1")', c)  # drop readConverterExp entirely
    c = re.sub(r'    /\*\* \$column\.columnComment \*/\r?\n', '', c)                                   # drop unrendered comment line
    c = re.sub(r'@Excel\(name = "\$\{comment\}"\)', '@Excel(name = "状态")', c)
    open(f, 'w').write(c)
```
Scan with `grep -rn "\$column\|\$comment\|readConverterExp" .../domain/Jl*.java` to find all affected files.

### 21. Generated `/system/{business}` routes collide with RuoYi built-ins

The generator defaults to `@RequestMapping("/system/{businessName}")`. Business names derived from table prefixes can collide with RuoYi's own controllers. Observed collisions:

- `jl_channel_goods_config` → businessName `config` → `/system/config` **collides with SysConfigController** (参数设置 menu 106, perms `system:config:*`)
- `jl_notice` → `/system/notice` **collides with SysNoticeController**

**Fix**: rename the collision before compiling — backend `@RequestMapping` + all `@PreAuthorize` perms + frontend api js + frontend views dir:
- `config` → `goodsconfig` (`/system/goodsconfig`, `system:goodsconfig:*`)
- `notice` → `jlnotice` (`/system/jlnotice`, `system:jlnotice:*`); generate a separate `jlnotice.js` with renamed functions (`listJlNotice` etc.) so it doesn't shadow RuoYi's `notice.js`/`listNotice`.

Check all routes are unique after renaming: `grep -rh "@RequestMapping" .../controller/Jl*.java | sort | uniq -d` (must be empty) and cross-check against `jonlink-admin/src/main/java/com/jonlink/web/controller/**`.

### 22. Landing generated code: menu component/perms alignment + role binding

Generated zip's `<business>Menu.sql` inserts menus under 系统工具 with perms `system:{biz}:*`, but if menus were pre-created (e.g. hand-written business menus with custom perms), **do NOT run the Menu.sql** (duplicate rows). Instead align existing menu rows to the generated files:

1. **C menus**: `UPDATE sys_menu SET component='system/{biz}/index' WHERE menu_id=N` — the component must exactly match `src/views/system/{biz}/index.vue`.
2. **F buttons**: perms must exactly match the Controller's `@PreAuthorize("@ss.hasPermi('system:{biz}:list/add/edit/remove/export/query')")` strings, else buttons 403.
3. **admin role binding**: admin bypasses perm checks (`hasPermi` special-cases `role_key=admin`), but bind anyway for robustness:
   ```sql
   INSERT IGNORE INTO sys_role_menu (role_id, menu_id) SELECT 1, menu_id FROM sys_menu WHERE menu_id >= <first-new-id>;
   ```
4. **Verify via getRouters**: login → `GET /getRouters` → walk the tree; every C menu's `component` must match a real file under `src/views/`.

### 23. Generated frontend files can overwrite RuoYi originals — check git before trusting

Copying `vue/api/system/*.js` and `vue/views/system/*` over `src/` **silently overwrites RuoYi's own files** when names collide. Observed: generated `config.js` clobbered RuoYi's `@/api/system/config` (which `main.js` imports `getConfigKey` from) → vite `Pre-transform error: Failed to resolve import "@/api/system/config"`.

**Fix**: after copying, `cd admin-web && git status --short src/api src/views` — any `M`/`D` on pre-existing files is suspicious. Restore originals: `git checkout -- src/api/system/config.js src/views/system/config/index.vue src/api/system/notice.js src/views/system/notice/index.vue`. Keep generated versions under unique names (`goodsconfig.js`, `jlnotice.js`).

### 24. Spring Boot fat jar: `unzip -l` top-level does NOT show nested module classes

Business classes live in `BOOT-INF/lib/jonlink-system-*.jar` (a nested jar), not as top-level entries. `unzip -l app.jar | grep JlProduct` returns nothing even though classes are inside. **This is not a packaging failure.**

**Fix** (verify nested contents):
```bash
unzip -q app.jar 'BOOT-INF/lib/jonlink-system-*.jar' -d /tmp/jarcheck
unzip -l /tmp/jarcheck/BOOT-INF/lib/jonlink-system-*.jar | grep -c "Jl.*Controller"   # expect 18
```
Also confirm the module is actually a dependency: `grep -A2 'jonlink-system' jonlink-admin/pom.xml` — it may come transitively via `jonlink-framework`. The authoritative end-to-end check is: login → hit `GET /system/{biz}/list` with Bearer token → expect `code:200` (not 404/401).

## CRUD generation pattern (10+ tables)

For "generate CRUD for ~10-20 tables" requests:

1. Define table fields as Python dict: `{'product': {'name': '产品', 'fields': [('Long','id',...), ('String','productName',...), ...], 'perms': 'jl:product', 'class': 'Product'}, ...}`
2. Generate for each table: `Domain.java`, `Mapper.java`, `Mapper.xml`, `IService.java`, `ServiceImpl.java`, `Controller.java`
3. Write to: `<module>/src/main/java/<base>/{domain,mapper,service,service/impl}/` + `<admin>/src/main/java/.../web/controller/`
4. Post-process: `{{` → `{`, `}}` → `}` (see pitfall 6)
5. For XML tables, run snake_case fix (see pitfall 5)
6. Wire into parent `pom.xml` `<dependencyManagement>` if new module

## Verification recipe (after bootstrap)

```bash
# Backend health
curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8080/    # expect 200

# Login (after captcha disabled)
TOKEN=$(curl -s -X POST http://127.0.0.1:8080/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"admin123"}' | jq -r .token)

# List businesses
curl -s http://127.0.0.1:8080/insure/product/list -H "Authorization: Bearer $TOKEN"

# Swagger UI (proves all controllers wired)
curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8080/swagger-ui.html  # expect 302

# API count (proves all controllers loaded)
curl -s http://127.0.0.1:8080/v3/api-docs | jq '.paths | keys | length'

# Menu title sanity (catches 乱码 in pitfall 13)
curl -s http://127.0.0.1:8080/getRouters -H "Authorization: Bearer $TOKEN" \
  | jq '.data[].meta.title' | head -10
# expect: "产品管理" / "系统管理" / "用户管理" — NOT ç³»ç»Ÿç®¡ç†
```

## Reference files

- `references/maven-multi-module.md` — dependencyManagement, parent/child pom patterns, the mvn install → java -jar sequence
- `references/docker-mysql-redis-init.md` — docker-compose config, initdb.d lifecycle, registry mirror setup, captcha-via-Redis
- `references/mybatis-xml-template-escape.md` — Python template → MyBatis XML gotchas (double brace, snake_case leak, #{} regex bug)
- `references/yaml-crlf-patch.md` — preserving CRLF when patching application.yml
- `references/ruoyi-framework-quirks.md` — @Anonymous, @PreAuthorize, captcha, jwt secret, swagger auto-init
- `references/vue3-vite-setup.md` — npm install devDeps, port 80, xdg-open, proxy /dev-api, **charset-removal postcss fix (pitfall 14)**
- `references/verification-recipes.md` — curl-based smoke tests for each major API group
- `references/mysql-utf8-recovery.md` — diagnosing and repairing double-encoded Chinese rows (pitfall 13)
- `references/code-generator-recipe.md` — RuoYi `/tool/gen` end-to-end workflow: import table → edit display flags → preview → download zip → unpack → copy to module → run `<business>Menu.sql` → rebuild. Includes which `.vm` templates to patch for non-default module paths and parent_id.
- `references/batch-generator-landing.md` — landing generated code for 10-20 tables at once via `batchGenCode` API: zip layout, sys_menu component/perms alignment, orphan-table menus, compile-fix loop, end-to-end verification checklist (pitfalls 20-24).
- `references/ruoyi-site-reverse-engineering.md` — extracting a competitor RuoYi admin's menu tree / API routes / field schemas from the minified SPA bundle + a JWT, without a browser: baseURL discovery, auth-header probing, getRouters dump, field inference from validation errors, and pivoting to hand-designed tables when the token is low-privilege.